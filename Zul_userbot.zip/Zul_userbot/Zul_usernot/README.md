<h1 align="center"> ᴄɪᴇ ᴅᴀʜ ʙɪsᴀ ɢᴄᴀsᴛ ᴀᴡᴏᴋᴡᴏᴋ<h1 align="center">


<p align="center">
    <a href="https://github.com/UserbotMaps/Hiroshi-Userbot/commits/Hiroshi-Userbot"><img src="https://img.shields.io/github/last-commit/UserbotMaps/Hiroshi-Userbot?color=ff0000&logo=github&logoColor=ffffff&style=for-the-badge" /></a>
    <a href="https://github.com/UserbotMaps/Hiroshi-Userbot"> <img src="https://img.shields.io/github/repo-size/UserbotMaps/Hiroshi-Userbot?logo=github&style=for-the-badge" /></a>
    <a href="https://pypi.org/project/Telethon/"><img src="https://img.shields.io/pypi/v/telethon?color=important&label=telethon&logo=python&logoColor=brightgreen&style=for-the-badge" /></a>
    <img alt="PYTHON" src="https://img.shields.io/badge/PYTHON-v3.9.6-purple?style=for-the-badge&logo=appveyor"/>
    </p>

<h1 align="center"> ʜɪʀᴏsʜɪ ᴜsᴇʀʙᴏᴛ <h1 align="center">


<p align="center">
  <img src="https://telegra.ph/file/040c6a31ae08e75059ccf.jpg">
</p>


## Disclaimer

```
Saya tidak bertanggung jawab atas penyalahgunaan bot ini.
Bot ini dimaksudkan untuk bersenang-senang sekaligus membantu Anda
mengelola grup secara efisien dan mengotomatiskan beberapa hal yang membosankan.
Gunakan bot ini dengan risiko Anda sendiri, dan gunakan dengan bijak.
```


## String Session :
[![GenerateStringName](https://img.shields.io/badge/repl.it-generateStringName-white)](https://replit.com/@rizkyhmdanii16/StringSession)

<h2 align="center">
   Metode Deploy
</h2>

<p align="center">
<a href="https://dashboard.heroku.com/new?template=https://github.com/UserbotMaps/Hiroshi-Userbot"><img src="https://img.shields.io/badge/Deploy%20To%20Heroku-blueviolet?style=for-the-badge&logo=heroku" width="250""/</a>  
<a href="https://telegram.dog/XTZ_HerokuBot?start=bXVoYW1tYWRyaXpreTE2L0t5eS1Vc2VyYm90IEt5eS1Vc2VyYm90"><img src="https://img.shields.io/badge/Deploy%20Via%20Telegram-blue?style=for-the-badge&logo=telegram" width="250""/</a>  </p>


### Support & Updates 
<a href="https://t.me/hiroshisupport"><img src="https://img.shields.io/badge/Join-Group%20Support-red.svg?style=for-the-badge&logo=Telegram"></a> <a href="https://t.me/hiroshimabes"><img src="https://img.shields.io/badge/Join-Updates%20Channel-white.svg?style=for-the-badge&logo=Telegram"></a>

### Follow Me :
<p align="left">
<a href="https://github.com/UserbotMaps"><img src="https://img.shields.io/badge/GitHub-Follow%20on%20GitHub-inactive.svg?logo=github"></a> <a href="https://instagram.com/ismail.neey"><img src="https://img.shields.io/badge/Instagram-Follow%20on%20Instagram-important.svg?logo=instagram"></a>
</p>

##

🔰 **THANKS YOU TO**
*   [Hiroshi](https://github.com/UserbotMaps/Hiroshi-Userbot) Hiroshi-Userbot
*   [Kyy](https://github.com/muhammadrizky16/Kyy-Userbot)   Kyy - Userbot
*   [Sendi](https://github.com/SendiAp/Rose-Userbot)   Rose-Userbot
*   [Skyzu](https://github.com/Skyzu/skyzu-userbot)   skyzu-userbot
*   DAN TERIMAKASIH KEPADA USERBOT LAINNYA
