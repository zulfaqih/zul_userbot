# Gausah kesini ngentot!!
# NGEDIT CMD YG BENER KONTOL!!!
# OWN MY CODE RENDY
# FILE BY RENDY

from platform import uname
from userbot import ALIVE_NAME, CMD_HELP, CMD_HANDLER, bot
from userbot.events import register

# ================= CONSTANT =================
DEFAULTUSER = str(ALIVE_NAME) if ALIVE_NAME else uname().node
# ============================================

@register(outgoing=True, pattern='^.hekel(?: |$)(.*)')
async def typewriter(typew):
    typew.pattern_match.group(1)
    await typew.edit("**SAYA GANTENG HEKEL BOS YAHAHAHA KONTOL.**")
    
@register(outgoing=True, pattern='W(?: |$)(.*)')
async def typewriter(typew):
    typew.pattern_match.group(1)
    await typew.edit("**WAR WAR PALAK BAPAK KAU WAR, SOK KERAS BANGET GOBLOK DI TONGKRONGAN JADI BABU DI TELE SOK JAGOAN.**")
    
@register(outgoing=True, pattern='^.dih(?: |$)(.*)')
async def typewriter(typew):
    typew.pattern_match.group(1)
    await typew.edit("**DIHH NAJISS ANAK HARAM LO GOBLOK JANGAN BELAGU DIMARI KAGA KEREN LU KEK BEGITU TOLOL.**")
    
@register(outgoing=True, pattern='^.gembel(?: |$)(.*)')
async def typewriter(typew):
    typew.pattern_match.group(1)
    await typew.edit("**MUKA BAPAK LU KEK KEPALA SAWIT ANJING, GA USAH NGATAIN ORANG, MUKA LU AJA KEK GEMBEL TEXAS GOBLOK!!.**")
    
@register(outgoing=True, pattern='^.sokab(?: |$)(.*)')
async def typewriter(typew):
    typew.pattern_match.group(1)
    await typew.edit("**SOKAB BET LU GOBLOK, KAGA ADA ISTILAH NYA BAWAHAN TEMENAN AMA BOS!!.**")
    
@register(outgoing=True, pattern='^.ded(?: |$)(.*)')
async def typewriter(typew):
    typew.pattern_match.group(1)
    await typew.edit("**MATI AJA LU GOBLOK GAGUNA LU HIDUP DI BUMI.**")
    
@register(outgoing=True, pattern='^.caper(?: |$)(.*)')
async def typewriter(typew):
    typew.pattern_match.group(1)
    await typew.edit("**NAMANYA JUGA JAMET CAPER SANA SINI BUAT CARI NAMA.**")
    
@register(outgoing=True, pattern='^.lo(?: |$)(.*)')
async def typewriter(typew):
    typew.pattern_match.group(1)
    await typew.edit("**CUIIHHH, MAKAN AJA MASIH NGEMIS LO GOBLOK, JANGAN SO NINGGI YA KONTOL GA KEREN LU KEK GITU GOBLOK.**")
    
@register(outgoing=True, pattern='^.pmblok(?: |$)(.*)')
async def typewriter(typew):
    typew.pattern_match.group(1)
    await typew.edit("**ANAK KONTOL ANAK NGENTOT, KALO NGECHAT MAJIKAN GUA ITU SALAM, HABIS ITU SABAR TUNGGU MAJIKAN GUA BALES, KALO GA DI BALES-BALES LU JANGAN NYEPAM KONTOL, KAYA ANAK YATIM MAU MINTA SEMBAKO LU ANJING, APA LAGI LU NGECHAT NYA CUMA MINTA VCS, BISA GUA BLOKIR!! KALO NYEPAM JUGA TAR GUA BLOKIR!!! TUNGGU SI GUA NERIMA PESAN LU.**")
    
@register(outgoing=True, pattern='^.sepi(?: |$)(.*)')
async def typewriter(typew):
    typew.pattern_match.group(1)
    await typew.edit("**KEK HATI LO BEGO😆.**")

@register(outgoing=True, pattern='^.woi(?: |$)(.*)')
async def typewriter(typew):
    typew.pattern_match.group(1)
    await typew.edit("**WOI LU SEMUA BABI😠.**")
 
@register(outgoing=True, pattern='^.ngatur(?: |$)(.*)')
async def typewriter(typew):
    typew.pattern_match.group(1)
    await typew.edit("**WOI ANJING, DENGER YA, ORANG GAK USAH NGATUR NGATUR HIDUP ORANG YA NGENTOT, URUS AJA HIDUP LU SENDIRI BANGSAT, UDAH BENER APA KAGAK.**")

@register(outgoing=True, pattern='^.ubot(?: |$)(.*)')
async def typewriter(typew):
    typew.pattern_match.group(1)
    await typew.edit("**GW TAU LU USERBOT TAPI GAUSAH NORAK NGENTOT.**")
              
@register(outgoing=True, pattern='^D(?: |$)(.*)')
async def typewriter(typew):
    typew.pattern_match.group(1)
    await typew.edit("**BACOT NGENTOTTT BAPA LU SURUH RIBUT SAMA GUA.**")
              
@register(outgoing=True, pattern='^E(?: |$)(.*)')
async def typewriter(typew):
    typew.pattern_match.group(1)
    await typew.edit("**GAK USAH SOK KERAS GOBLOK!!KENCING MASIH BERDIRI AJA BELAGU.**")
              
@register(outgoing=True, pattern='^F(?: |$)(.*)')
async def typewriter(typew):
    typew.pattern_match.group(1)
    await typew.edit("**MUKA LU SEMUA KAYA KONTOL HAHAHAHA.**")
              
@register(outgoing=True, pattern='^I(?: |$)(.*)')
async def typewriter(typew):
    typew.pattern_match.group(1)
    await typew.edit("**KONTOL MASIH BENGKOK AJA BANGGA LU HAHAHAHA!!.**")
              
@register(outgoing=True, pattern='^Q(?: |$)(.*)')
async def typewriter(typew):
    typew.pattern_match.group(1)
    await typew.edit("**EHH GOBLOK LU SEMUA RIBUT SAMA GUA SINI NGENTOT!.**")
              
@register(outgoing=True, pattern='^R(?: |$)(.*)')
async def typewriter(typew):
    typew.pattern_match.group(1)
    await typew.edit("**AKU SAYANG KAMU MWAHHH😭.**")
              
@register(outgoing=True, pattern='^T(?: |$)(.*)')
async def typewriter(typew):
    typew.pattern_match.group(1)
    await typew.edit("**BABI!!KONTOL!!NGENTOT!!!.**")
              
@register(outgoing=True, pattern='^U(?: |$)(.*)')
async def typewriter(typew):
    typew.pattern_match.group(1)
    await typew.edit("**BABI LU GOBLOK!!GANTENGAN JUGA GUA BHAHAHAHA.**")
              
@register(outgoing=True, pattern='^.cantik(?: |$)(.*)')
async def typewriter(typew):
    typew.pattern_match.group(1)
    await typew.edit("**KAMU CANTIK BANGET😍.**")
              


CMD_HELP.update({
    "toxic3":
    ".hekel\
    \nUsage:\
    \n\nW\
    \nUsage:\
    \n\n.dih\
    \nUsage:\
    \n\n.gembel\
    \nUsage:\
    \n\n.sokab\
    \nUsage:\
    \n\n.ded\
    \nUsage:\
    \n\n.caper\
    \nUsage:\
    \n\n.lo\
    \nUsage:\
    \n\n.pmblok\
    \nUsage:pc blok tolol😂\
    \n\n.sepi\
    \nUsage:"
}) 


CMD_HELP.update({
	"toxic4":
	".woi\
	\nUsage:\
	\n\n.ngatur\
	\nUsage:\
	\n\n.ubot\
	\nUsage:\
	\n\nD\
	\nUsage:\
	\n\nE\
	\nUsage:\
	\n\nF\
	\nUsage:\
	\n\nI\
	\nUsage:\
	\n\nQ\
	\nUsage:\
	\n\nR\
	\nUsage:\
	\n\nT\
	\nUsage:\
	\n\nU\
	\nUsage:\
	\n\n.cantik\
	\nUsage:"
	
}) 
