# ReCode by @skyzuex
# FROM skyzu-userbot <https://github.com/Skyzu/skyzu-userbot>
# KONTOLLLL

from platform import uname
from userbot import bot, ALIVE_NAME, CMD_HELP, CMD_HANDLER, bot
from userbot.events import register

# ================= CONSTANT =================
DEFAULTUSER = str(ALIVE_NAME) if ALIVE_NAME else uname().node
# ============================================


@register(outgoing=True, pattern=r"^\.sok(?: |$)(.*)")
async def typewriter(typew):
    typew.pattern_match.group(1)
    sleep(1.5)
    await typew.edit("**WOII**")
    sleep(1.5)
    await typew.edit("**KONTOL**")
    sleep(1.5)
    await typew.edit("**KALO MENTAL MASIH PATUNGAN**")
    sleep(1.5)
    await typew.edit("**GAUSAH SOK KERAS DEH**")
    sleep(1.5)
    await typew.edit("**GA KEREN LO BEGITU NGENTOT**")



@register(outgoing=True, pattern=r"^\.kont(?: |$)(.*)")
async def typewriter(typew):
    typew.pattern_match.group(1)
    sleep(1)
    await typew.edit("**KONTOLL**")
    sleep(1.5)
    await typew.edit("**LU ANAK KONTOLL**")
    sleep(1.5)
    await typew.edit("**DI BIKIN DARI KONTOLL**")
    sleep(1.5)
    await typew.edit("**MUKALU PERSIS KONTOLL**")
    sleep(1.5)
    await typew.edit("**DASAR ANAK NGONTOLLLL**")
    sleep(1.5)
    await typew.edit("**NOLEP KONTOLL**")
    sleep(1.5)
    await typew.edit("**NGERUSUH KONTOLL**")
    sleep(1.5)
    await typew.edit("**BENER BENER KONTOLL**")
    sleep(1.5)
    await typew.edit("**PADAHAL LO GAPUNYA KONTOLL**")
    sleep(1.5)
    await typew.edit("**MENDING LO OPERASI KONTOLL**")
    sleep(1.5)
    await typew.edit("**BIAR LO PUNYA KONTOLL**")
    sleep(1.5)
    await typew.edit("**KASIAN CACAD GAPUNYA KONTOLL**")


@register(outgoing=True, pattern=r"^\.an(?: |$)(.*)")
async def typewriter(typew):
    typew.pattern_match.group(1)
    await typew.edit(
        "**LO KAN HASIL ZINAH HASIL HUB TERLARANG NAH LO DI BUANG DI TONGSAMPAH NAH MAK LO YG SKRG KASIAN SAMA LO MKNY DI PUNGUT UDH LO CACAT KAKI CACAT TANGAN CACAT MUKA CACAT SEMUAHNY PARAH BET SI KONTOL LO JUGA CACATAN PASTI NANAHAN JUGA,UDH MENDING LO BUNDIR DEH JADI BEBAN ORG DOANG BEGO NGERUGIN MASYARKAT BEGO BOCAH HINA BOCAH HARAM BOCAH AUTIS KEK LO MENDING MATI AJA**"
    )


@register(outgoing=True, pattern=r"^\.bk(?: |$)(.*)")
async def typewriter(typew):
    typew.pattern_match.group(1)
    await typew.edit(
        "**BUAT LO KONTOL NIH KALO UDAH HINA GAUSAH SOK SOK NGEHINA HINA GUA KONTOL, GUA TERLALU SUCI BUAT LU YANG HINA ITU ADUHHH. SINI GUA LUDAHIN DLU LU BIAR DIRI LU SUCI KARENA LU TAU LUDAH GUA ITU MULIA SEKALI**"
    )


@register(outgoing=True, pattern=r"^\.gj(?: |$)(.*)")
async def typewriter(typew):
    typew.pattern_match.group(1)
    await typew.edit(
        "**YA AMPUN LU NGOMONG APA? GA NYAMBUNG KONTOL KAYA KEHIDUPAN LU MAKANYA ORG ORG KAYA LU GABAKALN MAJU HIDUPNYA APA LAGI ORG ORG BAWAHAN KAYA LU.**"
    )


@register(outgoing=True, pattern=r"^\.gh(?: |$)(.*)")
async def typewriter(typew):
    typew.pattern_match.group(1)
    await typew.edit(
        "**DUH GINI NIH BOCAH YG LAHIR DI GUBUK BAMBU REOT + GAPUNYA HARGA DIRI, PADAHAL MAH DARI KECIL DIAJARIN SM EMAKNYA GABOLEH SONGONG SM MAJIKAN MASIH AJA SONGONG, MENDING LO URUSIN DULU GOBLOK KELUARGA LO YG PENYAKITAN ITU, MANA BAPA LO KAKINYA BOROK BEGITU AJG BERNANAH BAU AMIS IDIH GELI BET GELI GUA LIATNYA, NAH SEKALIAN TUH URUSIN JUGA ADE LO TUH, KALO BUKAN KARENA GUA MAH ADE LO UDAH MENINGGAL KENA TUMOR TOLOL MAKANYA LO KUDU SUJUD DEPAN GUA YAKAN,EMAK LO JUGA TUH JAGAIN UDAH BISU BEGITU YAKAN TAKUTNYA JATOH GABISA TREAK, MAKANYA NIH YA JANGAN KEBANYAKAN KONSUMSI SASA MICIN GOBLOK LIAT KAN EFEKNYA LO JADI KEK BOCAH AYAN BEGITU, SAMPE² LO BERANI GITU YAKAN NYENGGET JEMURAN ORANG SAMPE LO DIPUKULIN TRUS DI INJEK² SAMA WARGA SEKAMPUNGAN, GINI YA GUA KASIH TAU NIH SAMA LO NIH KALO UDA MISKIN KAGA USAH BELAGU SEGALA TOLOL, MIKIR LO MAKAN AJA SUSAH SAMPE NGEMIS² DI KOMPLEK PERUMAHAN GUA SAMPE DI USIR SAMA SATPAM KOMPLEK GUA, BERAS AJA LO BOLEH DIBAGI SAMA EMAK GUA YAKAN LAUK PAUK IKAN, AYAM, DAGING SEGALA RUPA AJA LO BOLEH NYOLONG DARI PASAR BOCAH KAYA LO MAH GIZINYA KURANG DONGO SABAN HARI MAKAN INDOMI 1 PAKE TELOR DOANG ITU JUGA JOINAN SM KELUARGA LU, KARENA APA?, YA KARENA LO MISKIN GA MAMPU BELI MAKANAN YG BERGIZI, DIKASIH KUAH SAYUR KANGKUNG JUGA MAO TOLOL ITU JUGA UDAH BERSYUKUR BISA MAKAN MAKANAN SELAEN MI INSTAN YAKAN SECARA LO GABISA GITU KEK GUA YAKAN MAKAN APA YG GUA MAO LAH ELO MAKAN MAKANAN TONG SAMPAH JUGA UDAH ALHAMDULILLAH BANGET AJG**"
    )


@register(outgoing=True, pattern=r"^\.tholol(?: |$)(.*)")
async def typewriter(typew):
    typew.pattern_match.group(1)
    await typew.edit(
        "**TALAL TOLOL TALAL TOLOL KEK ORG DONGO, NIH YA DENGERIN MAKANYA BESOK² JANGAN NGELEM MULU OTAK LO, JADI LEMBEK DAH TUH PALA, MANA SABAN HARI MAKE SAMPO SACHET YG SEREBUAN GIMANA GA KETOMBEAN TU PALA, YA JELAS LAH BEDA SAMA GUA YA GUA SI PAKE SAMPO BOTOLAN GITU YAKAN, MANA SABUN BETAK DI RUMAH ORANG BEKAS COLI JUGA DIPAKE SAMA KELUARGA LO BUAT MANDI YA KARENA APA?, KARNA KELUARGA LO TUH HINA TOLOL BAHKAN LEBIH HINA DARIPADA HEWAN, LO KAGA PANTES MAEN TELE SUMPAH MENDING LO SEKOLAH DULU DAH YG BENER DI BIAYAIN AMA PEMERINTAH AJA GATAU DIRI KONTOL, LO PIKIR BAPA EMAK LO MAMPU GITU BIAYAIN LO SEKOLAH?, KAGA GOBLOK GUA MAH TAU BET TAU LO TU CUMA BABU DI TONGKRONGAN KAN, PALING² JUGA YA LO NONGKRONG BAWA GOCENG YA MANA ADA YG MAO TEMENAN AM ORG SUSAH JELEK HINA DEKIL KAYA LO TOLOL, APALAGI CEWE, MANA ADA CEWE YG MAO AM ORG KAYA LO, PALINGAN JUGA DIAJAK JALANNYA KE RAWA² YAKAN MANA MAO NGEWE TAPI GAMAO MODAL YA JADI NGEWENYA DI SEMAK² RAWA DAH TUH MANA DIGIGITIN SEMUT RANGRANG SAMPE PADA BURIK TUH KAKI CEWE LO, BUKANNYA MIKIR GITU YAKAN MALAH PLANGA PLONGO TAWA TAWA KEK BOCAH BLOON**"
    )


@register(outgoing=True, pattern="^.title(?: |$)(.*)")
async def typewriter(typew):
    typew.pattern_match.group(1)
    await typew.edit("**OI ANAK TITLE**")
    sleep(2)
    await typew.edit("**OOO INI YANG SOK JADI PAHLAWAN DI TELEGRAM?**")
    sleep(3)
    await typew.edit("**TITLE KEMANA MANA SAMPE MENUHIN NAMA**")
    sleep(2)
    await typew.edit("**ADA YANG SAMPE 18+ LAH SEGALA MACEM**")
    sleep(2)
    await typew.edit("**LO KIRA KEREN KEK GITU?**")
    sleep(2)
    await typew.edit("**KERJAAN CUMA NGURUSIN GRUP DI TELEGRAM SAMA NGAJAK ORANG WAR**")
    sleep(4)
    await typew.edit("**YAELAH BRO MENTAL LO CUMA DI SOSMED APA GIMANE?**")
    sleep(2)
    await typew.edit(
        "**PERASAAN DULU TELEGRAM GAADA DEH BOCAH BOCAH SOK JAGO KEK GINI**"
    )
    sleep(2)
    await typew.edit("**GILIRAN TITLE NYA DI EJEK NGADU KE OWNER NYA**")
    sleep(4)
    await typew.edit("**TRUS NGAJAK WAR**")
    sleep(2)
    await typew.edit("**BUSET DAH BANG**")
    sleep(2)
    await typew.edit("**UDAH SEJAGO APESI SAMPE GC DIBELA BELA**")
    sleep(3)
    await typew.edit("**ORANG TUA LO NOH ADA YANG NAGIH UTANG UDA LO BELA BELOM?**")
    sleep(4)
    await typew.edit("**RELA NGUTANG DEMI NGIDUPIN LU**")
    sleep(2)
    await typew.edit("**EH ANAKNYA MALAH NGEBELAIN GC GAJELAS HAHAHA**")
    sleep(3)
    await typew.edit("**MANA VIRTUAL LAGI, SOK JAGO LAGI DUH**")
    sleep(3)
    await typew.edit("**SEMOGA CEPET SADAR YA HAHAHAHA**")

@register(outgoing=True, pattern='^.ngentot(?: |$)(.*)')
async def typewriter(typew):
    typew.pattern_match.group(1)
    sleep(1)
    await typew.edit("**WOYY NGENTOD!!**")
    sleep(1)
    await typew.edit("**JANGAN SOK JAGOAN DAH LU**")
    sleep(1)
    await typew.edit("**MUKA MASIH KAYA KONTOL AJA**")
    sleep(1)
    await typew.edit("**BANGGA LU HAHAHAHA**")
    sleep(1)
    await typew.edit("**COBA DEH NGACA MUKA LU KAN HINA BANGET**")
    sleep(1)
    await typew.edit("**HAHAHAHA**")
    sleep(1)
    await typew.edit("**MAKANYA GANTENG KONTOL**")
    sleep(1)
    await typew.edit("**BIAR MUKALU GAK DIHINA TERUS**")
    sleep(1)
    await typew.edit("**SAMA ORANG LAIN**")
    sleep(1)
    await typew.edit("**HAHAHAHA**")
# Create by myself @localheart


@register(outgoing=True, pattern='^.goblok(?: |$)(.*)')
async def typewriter(typew):
    typew.pattern_match.group(1)
    sleep(1)
    await typew.edit("**WOYY GOBLOK!!**")
    sleep(1)
    await typew.edit("**KO LU GOBLOK BANGET SIH**")
    sleep(1)
    await typew.edit("**OTAK LU TUH KAYA KONTOL**")
    sleep(1)
    await typew.edit("**YANG LEMBEK KETIKA LEMAH**")
    sleep(1)
    await typew.edit("**DAN KERAS KETIKA LU SANGE GOBLOK**")
    sleep(1)
    await typew.edit("**HAHAHAHA**")
    sleep(1)
    await typew.edit("**MAKANYA JANGAN SANGEAN MULU**")
    sleep(1)
    await typew.edit("**MUKA LU AJA KAYA ASPAL JALANAN**")
    sleep(1)
    await typew.edit("**EHHH SANGE NYA MAU DAPAT YANG CANTIK**")
    sleep(1)
    await typew.edit("**HAHAHAHA**")
# Create by myself @localheart


@register(outgoing=True, pattern='^.ngatain(?: |$)(.*)')
async def typewriter(typew):
    typew.pattern_match.group(1)
    sleep(1)
    await typew.edit("**BABI!!**")
    sleep(1)
    await typew.edit("**MUKA LU KAYA BABI**")
    sleep(1)
    await typew.edit("**OTAK LU TUH KAYA KONTOL**")
    sleep(1)
    await typew.edit("**MUKA LU HINA BANGET**")
    sleep(1)
    await typew.edit("**OTAK LU KAYA BATU**")
    sleep(1)
    await typew.edit("**HAHAHAHA**")
    sleep(1)
    await typew.edit("**MAKANYA JANGAN SANGEAN MULU**")
    sleep(1)
    await typew.edit("**KONTOL LU AJA MASIH BENGKOK**")
    sleep(1)
    await typew.edit("**EHHH SANGE NYA MAU DAPAT YANG CANTIK**")
    sleep(1)
    await typew.edit("**HAHAHAHA**")

# Create by myself @localheart



CMD_HELP.update(
    {
        "toxic5": "𝘾𝙤𝙢𝙢𝙖𝙣𝙙: .sok\
         \n↳ : ngatain orang yang sok keras\
         \n𝘾𝙤𝙢𝙢𝙖𝙣𝙙: .bk\
         \n↳ : ngatain bocah hina\
         \n𝘾𝙤𝙢𝙢𝙖𝙣𝙙: .gh\
         \n↳ : lihat sendiri\
         \n𝘾𝙤𝙢𝙢𝙖𝙣𝙙: .kont\
         \n↳ : ngatain anak kontol\
         \n𝘾𝙤𝙢𝙢𝙖𝙣𝙙: .gj\
         \n↳ : ngatain bocah gajelas\
         \n𝘾𝙤𝙢𝙢𝙖𝙣𝙙: .tholol\
         \n↳ : ngatain bocah tolol\
         \n𝘾𝙤𝙢𝙢𝙖𝙣𝙙: .title\
         \n↳ : ngatain bocah gila title\
         \n𝘾𝙤𝙢𝙢𝙖𝙣𝙙: .an\
         \n↳ : ngatain anak pungut"
    }
)


# FILE BY RENDY

CMD_HELP.update({
    "toxic6":
    "𝘾𝙤𝙢𝙢𝙖𝙣𝙙: `.ngentot`\
    \n↳ : Lu Coba Sendiri Aja."
    "𝘾𝙤𝙢𝙢𝙖𝙣𝙙: `.goblok`\
    \n↳ : Lu Coba Sendiri Aja."
    "𝘾𝙤𝙢𝙢𝙖𝙣𝙙: `.ngatain`\
    \n↳ : Lu Coba Sendiri Aja."
})
