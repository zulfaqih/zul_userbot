
from time import sleep
from userbot import CMD_HANDLER as cmd
from userbot import CMD_HELP
from userbot.utils import edit_or_reply, hiro_cmd


@hiro_cmd(pattern="hujan(?: |$)(.*)")
async def _(event):
    xx = await edit_or_reply(event, f"`H`")
    await xx.edit("`Hm`")
    await xx.edit("`Hmm`")
    await xx.edit("`Hmmm`")
    await xx.edit("`Hmmmm`")
    await xx.edit("`Hmmmmm`")
    sleep(2)
    await xx.edit("`Hujan Hujan Gini Ange😔`")
    sleep(2)
    await xx.edit("`Enaknya Coli🤤`")
    sleep(1)
    await xx.edit("`8✊===D`")
    await xx.edit("`8=✊==D`")
    await xx.edit("`8==✊=D`")
    await xx.edit("`8===✊D`")
    await xx.edit("`8==✊=D`")
    await xx.edit("`8=✊==D`")
    await xx.edit("`8✊===D`")
    await xx.edit("`8=✊==D`")
    await xx.edit("`8==✊=D`")
    await xx.edit("`8===✊D`")
    await xx.edit("`8==✊=D`")
    await xx.edit("`8=✊==D`")
    await xx.edit("`8✊===D`")
    sleep(2)
    await xx.edit("`Ahhh🤤`")
    sleep(1)
    await xx.edit("`8✊===D`")
    await xx.edit("`8=✊==D`")
    await xx.edit("`8==✊=D`")
    await xx.edit("`8===✊D`")
    await xx.edit("`8==✊=D`")
    await xx.edit("`8=✊==D`")
    await xx.edit("`8✊===D`")
    await xx.edit("`8=✊==D`")
    await xx.edit("`8==✊=D`")
    await xx.edit("`8===✊D`")
    await xx.edit("`8==✊=D`")
    await xx.edit("`8=✊==D`")
    await xx.edit("`8✊===D`")
    await xx.edit("`crotss💦`")
    await xx.edit("`crotss💦💦`")
    await xx.edit("`crotss💦💦💦🤤`")
    sleep(2)
    await xx.edit("`H`")
    await xx.edit("`Hm`")
    await xx.edit("`Hmm`")
    await xx.edit("`Hmmm😔`")
    sleep(2)
    await xx.edit("`Ini Untuk Yang Terkahir`")
    sleep(2)
    await xx.edit("`Kenapa Ya Gw Coli Tadi😔`")
    sleep(2)
    await xx.edit("`Dah la besok besok ga mau lagi`")


@hiro_cmd(pattern="ange(?: |$)(.*)")
async def _(event):
    xx = await edit_or_reply(event, f"`Ayanggggg😖`")
    sleep(1)
    await xx.edit("`Ange😫`")
    sleep(1)
    await xx.edit("`Ayukkk Ewean Ayanggg🤤`")


@hiro_cmd(pattern="engas(?: |$)(.*)")
async def _(event):
    xx = await edit_or_reply(event, f"Udah nggak kuat nahan")
    sleep(1)
    await xx.edit("Pengen gitu-gituan")
    sleep(1)
    await xx.edit("Ayo cepat masukkan")
    sleep(1)
    await xx.edit("Jangan lama - lama")
    sleep(1)
    await xx.edit("Pliss cobain")
    sleep(1)
    await xx.edit("Jangan di nanti - nanti")
    sleep(1)
    await xx.edit("Ayo kita happy")
    sleep(1)
    await xx.edit("Tapi pake pengaman")


@hiro_cmd(pattern="dahla(?: |$)(.*)")
async def _(event):
    xx = await edit_or_reply(event, f"**`Ayo Menyerah`**")
    sleep(2)
    await xx.edit("**`Ngapain Semangat`**")


@hiro_cmd(pattern="ehm(?: |$)(.*)")
async def _(event):
    xx = await edit_or_reply(event, f"Eh..")
    sleep(2)
    await xx.edit("Suara kamu ga jelas")
    sleep(2)
    await xx.edit("Kayanya kalau call pribadi lebih jelas")
    sleep(2)
    await xx.edit("Gamau nyoba?")


# Nih buat lo yang sangean anjg.

@hiro_cmd(pattern="vc(?: |$)(.*)")
async def _(event):
    xx = await edit_or_reply(event, f"Kaa 🥺")
    sleep(2)
    await xx.edit("Temenin vc col*🥺 ")
    sleep(2)
    await xx.edit("Yuu kak temenin :( ")
    sleep(2)
    await xx.edit("Lagi tegang nihh")
    sleep(2)
    await xx.edit("Bentar doang ko 🥺")
    sleep(2)
    await xx.edit("Nanti aku tf deh janjii")


# P o c o n g U s e r b o t

CMD_HELP.update(
    {
        "animasi10": f"Perintah: **animasi10**\
    \n**Total Command: 4**\
    \nNih buat lo yg sangean anjg\
    \n\nㅤㅤ•**Syntax**: {cmd}hujan\
    \n•**Function**: __Penyesalan Seorang Laki-laki Yang Diulangin Terus Menerus__\
    \n\nㅤㅤ•**Syntax**: {cmd}engas\
    \n•**Function**: __Sange berat__\
    \n\nㅤㅤ•**Syntax**: {cmd}ange\
    \n•**Function**: __Ketik Ini Kalo Lu Lagi Sange__\
    \n\nㅤㅤ•**Syntax**: {cmd}vc\
    \n•**Function**: __Buat ngajakin kakak cantik vcs🥺__"

    })
