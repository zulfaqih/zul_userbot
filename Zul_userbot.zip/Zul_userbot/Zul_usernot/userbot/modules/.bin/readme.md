/bin/sh -c curl https://cli-assets.heroku.com/install.sh
