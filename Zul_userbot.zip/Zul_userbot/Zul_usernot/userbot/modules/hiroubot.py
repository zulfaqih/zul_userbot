# Copyright (C) 2021 Kyy - Userbot
# Created by Kyy
# Jangan hapus credit Anj!!!


from time import sleep
from userbot import CMD_HELP, CMD_HANDLER as cmd
from userbot.utils import edit_or_reply, hiro_cmd


@hiro_cmd(pattern="sadboy(?: |$)(.*)")
async def typewriter(typew):
    typew.pattern_match.group(1)
    sleep(2)
    xnxx = await edit_or_reply(typew, "`Pertama-tama kamu cantik`")
    sleep(2)
    await xnxx.edit("`Kedua kamu manis`")
    sleep(1)
    await xnxx.edit("`Dan yang terakhir adalah kamu bukan milikku`")


# Create by myself @localheart


@hiro_cmd(pattern="lahk(?: |$)(.*)")
async def typewriter(typew):
    typew.pattern_match.group(1)
    xnxx = await edit_or_reply(typew, "**Lahk, Lo tolol?**")
    sleep(1)
    await xnxx.edit("**Apa dongok?**")
    sleep(1)
    await xnxx.edit("**Gausah sok keras**")
    sleep(1)
    await xnxx.edit("**Gua ga ketrigger sama bocah baru nyemplung!**")


@hiro_cmd(pattern="sok(?: |$)(.*)")
async def typewriter(typew):
    typew.pattern_match.group(1)
    sleep(1.5)
    xnxx = await edit_or_reply(typew, "**WOII**")
    sleep(1.5)
    await xnxx.edit("**KONTOL**")
    sleep(1.5)
    await xnxx.edit("**KALO MENTAL MASIH PATUNGAN**")
    sleep(1.5)
    await xnxx.edit("**GAUSAH SOK KERAS DEH**")
    sleep(1.5)
    await xnxx.edit("**GA KEREN LO BEGITU NGENTOT**")


@hiro_cmd(pattern="wah(?: |$)(.*)")
async def typewriter(typew):
    typew.pattern_match.group(1)
    xnxx = await edit_or_reply(typew, "`Wahh, War nya keren bang`")
    sleep(2)
    await xnxx.edit("`Tapi, Yang gua liat, kok Kaya lawakan`")
    sleep(2)
    await xnxx.edit("`Oh iya, Kan lo badut 🤡`")
    sleep(2)
    await xnxx.edit("`Kosa kata pas ngelawak, Jangan di pake war bang`")
    sleep(2)
    await xnxx.edit("`Kesannya lo ngasih kita hiburan.`")
    sleep(2)
    await xnxx.edit("`Kasian badut🤡, Ga di hargain pengunjung, Eh lampiaskan nya ke Tele, Wkwkwk`")
    sleep(3)
    await xnxx.edit("`Dah sana cabut, Makasih hiburannya, Udah bikin Gua tawa ngakak`")


@hiro_cmd(pattern="alay(?: |$)(.*)")
async def typewriter(typew):
    typew.pattern_match.group(1)
    sleep(1)
    xnxx = await edit_or_reply(typew, "eh kamu, iya kamu")
    sleep(1)
    await xnxx.edit("**ALAY** bnget sih")
    sleep(1)
    await xnxx.edit("spam bot mulu")
    sleep(1)
    await xnxx.edit("baru jadi userbot ya?? xixixi")
    sleep(1)
    await xnxx.edit("pantes **NORAK**")


@hiro_cmd(pattern="erpe(?: |$)(.*)")
async def typewriter(typew):
    typew.pattern_match.group(1)
    sleep(1)
    xnxx = await edit_or_reply(typew, "Hai, Kamu Anak Erpe Ya")
    sleep(1)
    await xnxx.edit("Kok Pake Muka Orang sih?")
    sleep(1)
    await xnxx.edit("Oh iya, Muka Anak Erpe Kan")
    sleep(1)
    await xnxx.edit("**BURIK - BURIK**")
    sleep(1)
    await xnxx.edit("Jadinya Pake Muka Orang")
    sleep(1)
    await xnxx.edit("Karena Muka Anak erpe")
    sleep(1)
    await xnxx.edit("**BURIK - BURIK**")
    sleep(1)
    await xnxx.edit("Canda **BURIK**")
    sleep(1)
    await xnxx.edit("Lari Ada Plastik KePanasan")


@hiro_cmd(pattern="ange(?: |$)(.*)")
async def typewriter(typew):
    typew.pattern_match.group(1)
    xnxx = await edit_or_reply(typew, "`Ayanggggg😖`")
    sleep(1)
    await xnxx.edit("`Ange😫`")
    sleep(1)
    await xnxx.edit("`Ayukkk Ewean Ayanggg🤤`")


@hiro_cmd(pattern="virtual(?: |$)(.*)")
async def typewriter(typew):
    typew.pattern_match.group(1)
    xnxx = await edit_or_reply(typew, "**OOOO**")
    sleep(1.5)
    await xnxx.edit("**INI YANG VIRTUAL**")
    sleep(1.5)
    await xnxx.edit("**YANG KATANYA SAYANG BANGET**")
    sleep(1.5)
    await xnxx.edit("**TAPI TETEP AJA DI TINGGAL**")
    sleep(1.5)
    await xnxx.edit("**NI INGET**")
    sleep(1.5)
    await xnxx.edit("**TANGANNYA AJA GA BISA DI PEGANG**")
    sleep(1.5)
    await xnxx.edit("**APALAGI OMONGANNYA**")
    sleep(1.5)
    await xnxx.edit("**BHAHAHAHA**")
    sleep(1.5)
    await xnxx.edit("**KASIAN MANA MASIH MUDA**")


@hiro_cmd(pattern="tittle(?: |$)(.*)")
async def typewriter(typew):
    typew.pattern_match.group(1)
    xnxx = await edit_or_reply(typew, "**OI ANAK TITLE**")
    sleep(2)
    await xnxx.edit("**OOO INI YANG SOK JADI PAHLAWAN DI TELEGRAM?**")
    sleep(3)
    await xnxx.edit("**TITLE KEMANA MANA SAMPE MENUHIN NAMA**")
    sleep(2)
    await xnxx.edit("**ADA YANG SAMPE 18+ LAH SEGALA MACEM**")
    sleep(2)
    await xnxx.edit("**LO KIRA KEREN KEK GITU?**")
    sleep(2)
    await xnxx.edit("**KERJAAN CUMA NGURUSIN GRUP DI TELEGRAM SAMA NGAJAK ORANG WAR**")
    sleep(4)
    await xnxx.edit("**YAELAH BRO MENTAL LO CUMA DI SOSMED APA GIMANE?**")
    sleep(2)
    await xnxx.edit("**PERASAAN DULU TELEGRAM GAADA DEH BOCAH BOCAH SOK JAGO KEK GINI**")
    sleep(2)
    await xnxx.edit("**GILIRAN TITLE NYA DI EJEK NGADU KE OWNER NYA**")
    sleep(4)
    await xnxx.edit("**TRUS NGAJAK WAR**")
    sleep(2)
    await xnxx.edit("**BUSET DAH BANG**")
    sleep(2)
    await xnxx.edit("**UDAH SEJAGO APESI SAMPE GC DIBELA BELA**")
    sleep(3)
    await xnxx.edit("**ORANG TUA LO NOH ADA YANG NAGIH UTANG UDA LO BELA BELOM?**")
    sleep(4)
    await xnxx.edit("**RELA NGUTANG DEMI NGIDUPIN LU**")
    sleep(2)
    await xnxx.edit("**EH ANAKNYA MALAH NGEBELAIN GC GAJELAS HAHAHA**")
    sleep(3)
    await xnxx.edit("**MANA VIRTUAL LAGI, SOK JAGO LAGI DUH**")
    sleep(3)
    await xnxx.edit("**SEMOGA CEPET SADAR YA HAHAHAHA**")


CMD_HELP.update({
    "hiroubot": f"𝘾𝙤𝙢𝙢𝙖𝙣𝙙: `{cmd}sadboy`\
    \n↳ : Biasalah sadboy hikss\
    \n\n𝘾𝙤𝙢𝙢𝙖𝙣𝙙: `{cmd}wah`\
    \n↳ : Ngatain orang war\
    \n\n𝘾𝙤𝙢𝙢𝙖𝙣𝙙: `{cmd}sok`\
    \n↳ : Ngatain orang sok keras2\
    \n\n𝘾𝙤𝙢𝙢𝙖𝙣𝙙: `{cmd}lahk`\
    \n↳ : Ngatain orang sok keras.\
    \n\n𝘾𝙤𝙢𝙢𝙖𝙣𝙙: `{cmd}alay`\
    \n↳ : Ngatain orang alay\
    \n\n𝘾𝙤𝙢𝙢𝙖𝙣𝙙: `{cmd}erpe`\
    \n↳ : Ngatain anak erpe\
    \n\n𝘾𝙤𝙢𝙢𝙖𝙣𝙙: `{cmd}ange`\
    \n↳ : Sangean\
    \n\n𝘾𝙤𝙢𝙢𝙖𝙣𝙙: `{cmd}virtual`\
    \n↳ : Ngatain bocah virtual.\
    \n\n𝘾𝙤𝙢𝙢𝙖𝙣𝙙: `{cmd}tittle`\
    \n↳ : Ngatain bocah gila tittle."
})
