from time import sleep
from userbot import CMD_HELP, CMD_HANDLER as cmd
from userbot.utils import edit_or_reply, hiro_cmd


@hiro_cmd(pattern="jamet(?: |$)(.*)")
async def typewriter(typew):
    typew.pattern_match.group(1)
    x = await edit_or_reply(typew, "**WOII**")
    sleep(1.5)
    await x.edit("**JAMET KONTOL**")
    sleep(1.5)
    await x.edit("**CUMA MAU BILANG**")
    sleep(1.5)
    await x.edit("**GAUSAH SO ASIK**")
    sleep(1.5)
    await x.edit("**EMANG KENAL?**")
    sleep(1.5)
    await x.edit("**GAUSAH REPLY**")
    sleep(1.5)
    await x.edit("**KITA BUKAN KAWAN**")
    sleep(1.5)
    await d.edit("**GASUKA PC ANJING**")
    sleep(1.5)
    await x.edit("**BOCAH KAMPUNG**")
    sleep(1.5)
    await x.edit("**MENTAL TEMPE**")
    sleep(1.5)
    await x.edit("**LEMBEK NGENTOT🔥**")


@hiro_cmd(pattern="pp(?: |$)(.*)")
async def typewriter(typew):
    typew.pattern_match.group(1)
    await edit_or_reply(typew,
                        "**PASANG PP DULU NGENTOT,BIAR ORANG-ORANG PADA TAU BETAPA HINA NYA MUKA LU 😆**"
                        )


@hiro_cmd(pattern="dp(?: |$)(.*)")
async def typewriter(typew):
    typew.pattern_match.group(1)
    await edit_or_reply(typew, "**MUKA LU HINA, GAUSAH SOK KERAS YA NGENTOT!!**")


@hiro_cmd(pattern="so(?: |$)(.*)")
async def typewriter(typew):
    typew.pattern_match.group(1)
    await edit_or_reply(typew, "**GAUSAH SOKAB SAMA GUA NGENTOT, LU BABU GA LEVEL!!**")


@hiro_cmd(pattern="nb(?: |$)(.*)")
async def typewriter(typew):
    typew.pattern_match.group(1)
    await edit_or_reply(typew, "**MAEN BOT MULU ALAY NGENTOTT, KESANNYA NORAK GOBLOK!!!**")


@hiro_cmd(pattern="met(?: |$)(.*)")
async def typewriter(typew):
    typew.pattern_match.group(1)
    await edit_or_reply(typew, "**NAMANYA JUGA JAMET CAPER SANA SINI BUAT CARI NAMA BHAHAHA**")


@hiro_cmd(pattern="war(?: |$)(.*)")
async def typewriter(typew):
    typew.pattern_match.group(1)
    await edit_or_reply(event,
                        "**WAR WAR PALAK BAPAK KAU WAR, SOK KERAS BANGET GOBLOK, DI TONGKRONGAN JADI BABU, DI TELE SOK JAGOAN...**"
                        )


@hiro_cmd(pattern="wartai(?: |$)(.*)")
async def typewriter(typew):
    typew.pattern_match.group(1)
    await edit_or_reply(typew,
                        "**WAR WAR TAI ANJING, KETRIGGER MINTA SHARELOK LU KIRA MAU COD-AN GOBLOK, BACOTAN LU AJA KGA ADA KERAS KERASNYA TOLOL**"
                        )


@hiro_cmd(pattern="kismin(?: |$)(.*)")
async def typewriter(typew):
    typew.pattern_match.group(1)
    await edit_or_reply(typew,
                        "**CUIHHHH, MAKAN AJA MASIH NGEMIS LO GOBLOK, JANGAN SO NINGGI YA KONTOL GA KEREN LU KEK GITU NGENTOT!!**"
                        )


@hiro_cmd(pattern="ded(?: |$)(.*)")
async def typewriter(typew):
    typew.pattern_match.group(1)
    await edit_or_reply(typew, "**MATI AJA LU GOBLOK, GAGUNA LU HIDUP DI BUMI**")


@hiro_cmd(pattern="sokab(?: |$)(.*)")
async def typewriter(typew):
    typew.pattern_match.group(1)
    await edit_or_reply(typew,
                        "**SOKAB BET LU GOBLOK, KAGA ADA ISTILAH NYA BAWAHAN TEMENAN AMA BOS AHAHAHA!!**"
                        )


@hiro_cmd(pattern="gembel(?: |$)(.*)")
async def typewriter(typew):
    typew.pattern_match.group(1)
    await edit_or_reply(typew,
                        "**MUKA BAPAK LU KEK KELAPA SAWIT ANJING, GA USAH NGATAIN ORANG, MUKA LU AJA KEK GEMBEL TEXAS KONTOL!!**"
                        )


@hiro_cmd(pattern="cuih(?: |$)(.*)")
async def typewriter(typew):
    typew.pattern_match.group(1)
    await edit_or_reply(typew,
                        "**GAK KEREN LO KEK BEGITU GOBLOK, KELUARGA LU BAWA SINI GUA LUDAHIN SATU-SATU, SETDAH!!!**"
                        )


CMD_HELP.update(
    {
        "war": f"**Plugin : **`war`\
        \n\n  •  **Syntax :** `{cmd}jamet`\
        \n  •  **Function : **Menghina Jamet telegram\
        \n\n  •  **Syntax :** `{cmd}pp`\
        \n  •  **Function : **Menghina Jamet telegram yang ga pake foto profil\
        \n\n  •  **Syntax :** `{cmd}dp`\
        \n  •  **Function : **Menghina Jamet muka hina!\
        \n\n  •  **Syntax :** `{cmd}so`\
        \n  •  **Function : **Ngeledek orang sokab\
        \n\n  •  **Syntax :** `{cmd}nb`\
        \n  •  **Function : **Ngeledek orang norak baru pake bot\
        \n\n  •  **Syntax :** `{cmd}so`\
        \n  •  **Function : **Ngeledek orang sokab\
        \n\n  •  **Syntax :** `{cmd}skb`\
        \n  •  **Function : **Ngeledek orang sokab versi 2\
        \n\n  •  **Syntax :** `{cmd}met`\
        \n  •  **Function : **Ngeledek si jamet caper\
        \n\n  •  **Syntax :** `{cmd}war`\
        \n  •  **Function : **Ngeledek orang so keras ngajak war\
        \n\n  •  **Syntax :** `{cmd}wartai`\
        \n  •  **Function : **Ngeledek orang so ketrigger ngajak cod minta sharelok\
        \n\n  •  **Syntax :** `{cmd}kismin`\
        \n  •  **Function : **Ngeledek orang kismin so jagoan di tele\
        \n\n  •  **Syntax :** `{cmd}ded`\
        \n  •  **Function : **Nyuruh orang mati aja goblok wkwk\
        \n\n  •  **Syntax :** `{cmd}sokab`\
        \n  •  **Function : **Ngeledek orang so kenal so dekat padahal kga kenal goblok\
        \n\n  •  **Syntax :** `{cmd}gembel`\
        \n  •  **Function : **Ngeledek bapaknya si jamet\
        \n\n  •  **Syntax :** `{cmd}cuih`\
        \n  •  **Function : **Ngeludahin keluarganya satu satu wkwk\
        \n\n**Kalau Mau Req Kosa Kata Ke Owner Gua Ya Kontol ☞ @Bisubiarenak**\
    "
    }
)
