from time import sleep
from userbot import CMD_HELP, CMD_HANDLER as cmd
from userbot.utils import edit_or_reply, hiro_cmd


@hiro_cmd(pattern="aln(?: |$)(.*)")
async def typewriter(typew):
    typew.pattern_match.group(1)
    x = await edit_or_reply(typew, "**WOII**")
    sleep(1.5)
    await x.edit("**ANAK LACUR NAMA ALAY BEGITY**")
    sleep(1.5)
    await x.edit("**BEGO HIDUP LU DIPENUHI SAMA KEALAYAAN LU KONTOL MAIN AJA LU DISAWAH KAN TOLOL**")
    sleep(1.5)
    await x.edit("**SAMBIL DENGERIN SUARA JANGKRIK BEGITU YANG BERISIK KAYAK RUMAH LU**")
    sleep(1.5)
    await x.edit("**BERISIK KARNA LAGI KEBAKARAN BEGITU?**")
    sleep(1.5)
    await x.edit("**TAPI DIBIARIN AJA KARNA RUMAH LU AJA TERCIPTA DARI BOTOL BOTOLAN BEGITU**")
    sleep(1.5)
    await x.edit("**MAKANYA LU DIPANGGILNYA BOTOL BOCAH TOLOL YANG**")
    sleep(1.5)
    await d.edit("**MASIH ANAK KEMARIN SORE**")
    sleep(1.5)
    await x.edit("**YANG MAIN TELE CUMAN NYARI BOKEP DOANG OTAK BOKEP**")
    sleep(1.5)
    await x.edit("**MENTAL TEMPE**")
    sleep(1.5)
    await x.edit("**LEMBEK NGENTOT🔥**")


@hiro_cmd(pattern="mag(?: |$)(.*)")
async def typewriter(typew):
    typew.pattern_match.group(1)
    await edit_or_reply(typew,
                        "**MULUNG APAANSI BEGO LU AJA HIDUPNYA MASIH DI KOLONG JEMBATAN BEGO BELAGU KONTOL PAKE MAEN TELE SGLA GW TAU TU HP NOKIA JADUL YEKAN YG DI PEMBUANGN SMPAH TRS LU PUNGUT AMPE BELI PAKET AJA LU MASIH NGEMIS BEGO HDDH KSIAN BET KSIAN IDUP LO KONTOL**"
                        )


@hiro_cmd(pattern="dbn(?: |$)(.*)")
async def typewriter(typew):
    typew.pattern_match.group(1)
    await edit_or_reply(typew, "**DASARR BEBANN NEGARAA BHAKS MATII AJAA SANA LU BEGOO SUSULINN BAPAK LO DI NERAKA SANAA KASIANN DIAA DI SIKSA TITIT NYA KARENA KESERINGAN NYEWA JABLAYY BHAKSS!!**")


@hiro_cmd(pattern="ngen(?: |$)(.*)")
async def typewriter(typew):
    typew.pattern_match.group(1)
    await edit_or_reply(typew, "**GAUSAH SOKAB SAMA GUA NGENTOT, LU BABU GA LEVEL!!**")


@hiro_cmd(pattern="ueg(?: |$)(.*)")
async def typewriter(typew):
    typew.pattern_match.group(1)
    await edit_or_reply(typew, "**UDAH ELU GAUSAH ROASTING GUA ROASTINGAN ELU GAK GUNA GAK ADA RASANYA MENDING LU DIEM AJA WAHAI RAKYAT JELATA YANG SEHARI HARINYA MINTA SEKALINYA DIKASIH HARUS DI HINA APAKAH HIDUP YANG SEPERTI ITU BISA DISEBUT MULIA ATAU HINA WAHAI PEMIRSA!!!**")


@hiro_cmd(pattern="sss(?: |$)(.*)")
async def typewriter(typew):
    typew.pattern_match.group(1)
    await edit_or_reply(typew, "**SUDAH SUDAH SUDAH HEI MAKHLUK HAMPA YANG GAK GUNA GAK PUNYA MATA BISA DISEBUT BUTA ATAUPUN TUNANETRA**")


@hiro_cmd(pattern="ysh(?: |$)(.*)")
async def typewriter(typew):
    typew.pattern_match.group(1)
    await edit_or_reply(event,
                        "**YANG SETIAP HARI KENA KARMA MAU DIBANTUIN SAMA WARGA MALAH NGGAK DI TERIMA AHAHAHAHAHAHAAAAAAAA...**"
                        )


@hiro_cmd(pattern="bcp(?: |$)(.*)")
async def typewriter(typew):
    typew.pattern_match.group(1)
    await edit_or_reply(typew,
                        "**BEGINILAH CALON PENGHUNI NERAKAAAAAA HIDUPNYA PENUH LUKA MAU MASUK SURGA MALAH MEMAKSA**"
                        )


@hiro_cmd(pattern="sdl(?: |$)(.*)")
async def typewriter(typew):
    typew.pattern_match.group(1)
    await edit_or_reply(typew,
                        "**SADARIN DIRI LU KONTOL, SABARIN DIRI LU TOLOL, BIAR HIDUPNYA GAK BANYAK YANG NYENGGOL!!**"
                        )


@hiro_cmd(pattern="bosa(?: |$)(.*)")
async def typewriter(typew):
    typew.pattern_match.group(1)
    await edit_or_reply(typew, "**Bocah sakau, muka hina, anak haram kaya lu ga pantes lawan gua bego, lu masih bawahan gua, gua tau lu bocah tongkrongan yang kalo nongkrong ga pernah matung, tapi mintain roko temen lu, gua tau roko puntungan yang udah basah aja masih lu ambil saking miskinnya gamampu beli roko satu batang**")


@hiro_cmd(pattern="nitol(?: |$)(.*)")
async def typewriter(typew):
    typew.pattern_match.group(1)
    await edit_or_reply(typew,
                        "**Nih kontol gua bilangin sekali lagi lu idup juga percuma, gapunya tujuan hidup tolol, udah miskin belaga lagi bego, kemiskinan lu tuh bikin warga lu enek tau ga tolol, saking miskinnya Ema lu keliling kampung buat ngajakin warga kampung lu ngewein Ema lu yang di bayar seikhlasnya. Udah Ema ngelacur, bapanya jadi babi ngepet bego mau jadi apa masa depan lu tolol, duit hasil ngepet bapa lu aja ga cukup buat nurutin kebutuhan hidup anaknya yang so kaya tau ga kontol!!**"
                        )


@hiro_cmd(pattern="bgb(?: |$)(.*)")
async def typewriter(typew):
    typew.pattern_match.group(1)
    await edit_or_reply(typew,
                        "**DIH BEGO GAUSAH BELAGU GOBLOK LU AJA MISKIN AJG YG TIAP HARI HARUS TDR DI EMPERAN JALAN YG BER ALAS KARDUS DOANG WKWK DARIPADA LU DI SINI CMA JADI BAHAN BULLY DOANG MENDING SANA LU NGEMIS NYARI DUIT BUAT BIAYA BAPA LU YG LAGI NGULI PINGGANGNYA PATAH WKWKWK KADANG GUA SUKA KASIAN NGELIAT HIDUP LU YG PENUH PENDERITAAN MANA TINGGAL NYA DI HUTAN,TIDURNYA DI GOA YG KEPANASAN KEDINGINAN HAHA JAMETTT JAMETT BEGINI NIH KAO HASIL PERKAWINAN BABI HUTAN SAMA KUDANIL ANAK NYA ABSTRAKK YG GA KETAUAN WUJUD NYA SPERTI APAH WKWK THOLOL BAT THOLOL MANGKANYA JANGAN NGEJAMET MULU THOLOL!!**"
                        )


@hiro_cmd(pattern="dgg(?: |$)(.*)")
async def typewriter(typew):
    typew.pattern_match.group(1)
    await edit_or_reply(typew,
                        "**GAYA BANGET ANJING SOK MAU NGERUSIH DI GC GEDE TOLOL, HIDUP LU AJA PAS PAS AN TOLOL UDH MUKA HINA HIDUP HINA SEMUA SERBA HINA TOLOL DIKIRA MANTEP LU BEGITU? KAGAK TOLOL GAADA MANTEP MANTEP NYA SUMPAH, MIRIS BEGO GUA LIAT NYA BEGITU MENDING LU JAGA IN EMAK LU TOLOL ITU UDH SEKARAT BEGO BENTAR LAGI MATI TOLOL BENTAR LAGI DI NERAKA ITU MAU DI TUSUK TUSUK IBLIS TOLOL, MIRIS BET MIRIS DAH TUHAN AJA TERTAWA BEGO MELIHAT HAMBA NYA YG BEGININ TOLOL LU HIDUP ITU CUMAN BUAT DI HINA KONTOL, GAYA BET KONTOL MAU NGERUSIH IN GC GEDE KONTOL KEHIDUPAN YG SERBA KEKURANGAN SADAR DIRI KONTOL MUKA JELET BET JELEK GITU SOK MANTEP KONTOL, EMAK LU AJA TIAP MALEM DI SODOK SAMA SUPIR TRUK BEGO DI BAYAR 50K JUGA EMAK LU NGANGKANG TOLOL!!!**"
                        )


CMD_HELP.update(
    {
        "war5": f"**Plugin : **`war`\
        \n\n  •  **Syntax :** `{cmd}aln`\
        \n  •  **Function : **Hina Hina Orang\
        \n\n  •  **Syntax :** `{cmd}mag`\
        \n  •  **Function : **Hina Hina Orang\
        \n\n  •  **Syntax :** `{cmd}dbn`\
        \n  •  **Function : **Hina Hina Orang!\
        \n\n  •  **Syntax :** `{cmd}ngen`\
        \n  •  **Function : **Ngeledek orang sokab\
        \n\n  •  **Syntax :** `{cmd}ueg`\
        \n  •  **Function : **Hina Hina Orang\
        \n\n  •  **Syntax :** `{cmd}sss`\
        \n  •  **Function : **Hina Hina Orang\
        \n\n  •  **Syntax :** `{cmd}ysh`\
        \n  •  **Function : **Hina Hina Orang\
        \n\n  •  **Syntax :** `{cmd}bcp`\
        \n  •  **Function : **Hina Hina Orang\
        \n\n  •  **Syntax :** `{cmd}sdl`\
        \n  •  **Function : **Hina Hina Orang\
        \n\n  •  **Syntax :** `{cmd}bosa`\
        \n  •  **Function : **Hina Hina Orang\
        \n\n  •  **Syntax :** `{cmd}nitol`\
        \n  •  **Function : **Hina Hina Orang\
        \n\n  •  **Syntax :** `{cmd}bgb`\
        \n  •  **Function : **Hina Hina Orang\
        \n\n  •  **Syntax :** `{cmd}dgg`\
        \n  •  **Function : **Hina Hina Orang\
        \n\n  •  **Syntax :** `{cmd}gembel`\
        \n  •  **Function : **Ngeledek bapaknya si jamet\
        \n\n  •  **Syntax :** `{cmd}cuih`\
        \n  •  **Function : **Ngeludahin keluarganya satu satu wkwk\
        \n\n**Kalau Mau Req Kosa Kata Ke Owner Gua Ya Kontol ☞ @Bisubiarenak**\
    "
    }
)
