# greyvbss

from time import sleep

from userbot import CMD_HANDLER as cmd, CMD_HELP
from userbot.utils import hiro_cmd


@hiro_cmd(pattern=r"heu(?: |$)(.*)")
async def _(typew):
    await typew.edit("▒▒▒▒▒▄██████████▄▒▒▒▒▒\n"
                     "▒▒▒▄██████████████▄▒▒▒\n"
                     "▒▒██████████████████▒▒\n"
                     "▒▐███▀▀▀▀▀██▀▀▀▀▀███▌▒\n"
                     "▒███▒▒▌■▐▒▒▒▒▌■▐▒▒███▒\n"
                     "▒▐██▄▒▀▀▀▒▒▒▒▀▀▀▒▄██▌▒\n"
                     "▒▒▀████▒▄▄▒▒▄▄▒████▀▒▒\n"
                     "▒▒▐███▒▒▒▀▒▒▀▒▒▒███▌▒▒\n"
                     "▒▒███▒▒▒▒▒▒▒▒▒▒▒▒███▒▒\n"
                     "▒▒▒██▒▒▀▀▀▀▀▀▀▀▒▒██▒▒▒\n"
                     "▒▒▒▐██▄▒▒▒▒▒▒▒▒▄██▌▒▒▒\n"
                     "▒▒▒▒▀████████████▀▒▒▒▒\n")


@hiro_cmd(pattern=r"hem(?: |$)(.*)")
async def _(typew):
    await typew.edit(" ╭━┳━╭━╭━╮╮\n"
                     " ┃┈┈┈┣▅╋▅┫┃\n"
                     " ┃┈┃┈╰━╰━━━━━━╮\n"
                     " ╰┳╯┈┈┈┈┈┈┈┈┈◢▉◣\n"
                     "   ╲┃┈┈┈┈┈┈┈┈┈┈▉▉▉\n"
                     "   ╲┃┈┈┈┈┈┈┈┈┈┈◥▉◤\n"
                     "   ╲┃┈┈┈┈╭━┳━━━━╯\n"
                     "   ╲┣━━━━━━┫\n"
                     "      **MENCURIGAKAN**\n")


@hiro_cmd(pattern=r"wle(?: |$)(.*)")
async def _(typew):
    await typew.edit("┈╭━━━━━━━━━━━╮┈\n"
                     "╭╯┈╭━━╮┈╭━━╮┈╰╮\n"
                     "┃┈┃┃╭╮┃┈┃╭╮┃┃┈┃\n"
                     "┃┈┃┻┻┻┛┈┗┻┻┻┃┈┃\n"
                     " ┃┈┃╭╮┈◢▇◣┈╭╮┃┈┃\n"
                     "╰┳╯┃╰━━┳┳┳╯┃╰┳╯\n"
                     "┈┃┈╰━━━┫┃┣━╯┈┃┈\n"
                     "┈┃┈┈┈┈┈╰━╯┈┈┈┃┈\n")


@hiro_cmd(pattern=r"peler(?: |$)(.*)")
async def _(typew):
    await typew.edit("`MAU LIAT PELER GA???`")
    sleep(1)
    await typew.edit("`NIHHHH DIAA`")
    sleep(1)
    await typew.edit("░░░░█─────────────█──▀──\n"
                     "░░░░▓█───────▄▄▀▀█──────\n"
                     "░░░░▒░█────▄█▒░░▄░█─────\n"
                     "░░░░░░░▀▄─▄▀▒▀▀▀▄▄▀──SIJONI─\n"
                     "░░░░░░░░░█▒░░░░▄▀────PANJANG\n"
                     "▒▒▒░░░░▄▀▒░░░░▄▀───DAN─\n"
                     "▓▓▓▓▒░█▒░░░░░█▄───PEMBERANI─\n"
                     "█████▀▒░░░░░█░▀▄───CROTT──\n"
                     "█████▒▒░░░▒█░░░▀▄─AHHH──\n"
                     "███▓▓▒▒▒▀▀▀█▄░░░░█──────\n"
                     "▓██▓▒▒▒▒▒▒▒▒▒█░░░░█─────\n"
                     "▓▓█▓▒▒▒▒▒▒▓▒▒█░░░░░█────\n"
                     "░▒▒▀▀▄▄▄▄█▄▄▀░░░░░░░█─\n")


@hiro_cmd(pattern=r"ahh(?: |$)(.*)")
async def _(typew):
    await typew.edit("ahhh")
    await typew.edit("ahhh ahhh")
    await typew.edit("ahhh ahhh ahhh")
    await typew.edit("🥵")
    sleep(1)
    await typew.edit("⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⡠⠢⠏⣉⣉⠣⢦⡀⠄⠄⠄⠄\n"
                     "⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⣐⢪⠅⣱⣟⢛⢧⠄⣷⠄⠄⠄⠄\n"
                     "⠄⠄⠄⠄⠄⠄⠄⠠⣬⣀⣢⣕⡽⢯⣩⣳⣷⠧⡆⠄⠄⠄\n"
                     "⠄⠄⠄⠄⠄⠄⠄⢠⡭⡾⣆⢿⡙⢟⢻⣿⡿⡹⣶⠅⠄⠄⠄ \n"
                     "⠄⠄⠄⠄⠄⠄⠄⣔⠄⡗⢫⠘⠷⠾⠿⠟⠙⣡⢢⢖⠄⠄⠄\n"
                     "⠄⠄⠄⠄⠄⠄⠄⢫⠺⠁⡹⢸⣿⣿⣿⡟⠲⣦⣌⢄⡇⠄⠄\n"
                     "⠄⠄⠄⠄⠄⠄⢀⡈⢛⠨⠥⡄⣿⣿⣿⣧⢯⡻⡇⠨⣁⠄⠄\n"
                     "⠄⠄⠄⠄⠄⢠⡤⢠⣶⣿⣿⣿⣿⣿⣿⣿⣷⢗⠵⡐⡣⡄⠄\n"
                     "⠄⠄⠄⠄⠄⠸⢡⣿⣿⣿⣿⣿⢿⣿⣿⣿⣿⣷⡄⢶⡇⡇⠄\n"
                     "⠄⠄⠄⠄⠄⣠⣿⣿⣿⣿⣿⠟⢸⣿⣿⣿⡟⡻⣿⠘⠧⡇⠄\n"
                     "⠄⠄⠄⠄⠄⢳⣿⣿⣿⡿⣫⣾⣜⢿⣿⣿⣷⣶⡿⢀⠗⡇⠄\n"
                     "⠄⠄⠄⠄⠄⣦⡝⣭⣵⣾⣿⣿⣿⣦⣍⣛⣛⣫⠡⣼⢾⣿⠄\n"
                     "⠄⠄⠄⠄⢰⣿⡇⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠄⠨⣿⡟⠄\n"
                     "⠄⠄⠄⢀⣿⡿⣿⢹⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⢆⣶⣿⠇⠄\n"
                     "⠄⠄⠄⢸⣿⣷⠎⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⢯⣿⣷⣻⡆⠄\n"
                     "⠄⠄⢀⣿⣿⠏⢸⡟⢿⣿⣿⣸⣿⣿⣿⣿⢏⣾⣿⣿⣏⣷⠄\n"
                     "⠄⠄⣸⣿⠏⢀⣼⣿⣎⡻⢿⣿⣿⣿⠿⣣⣾⣿⣿⣿⣿⣽⠄\n"
                     "⠄⠄⣿⡿⣰⣿⣿⣿⣿⣿ AHHH ⣰⣿⣿⣿⣿⣿⣿⣿\n")


CMD_HELP.update(
    {
        "animasi9": f"**Plugin : **`animasi8`\
        \n\n  •  **Syntax :** `{cmd}heu`\
        \n  •  **Function : **Mengirim Gambar Monyet.\
        \n\n  •  **Syntax :** `{cmd}hem`\
        \n  •  **Function : **Mengirim Gambar Anjing Mencurigakan.\
        \n\n  •  **Syntax :** `{cmd}wle`\
        \n  •  **Function : **Mengirim Gambar Anjing Melet.\
        \n\n  •  **Syntax :** `{cmd}peler`\
        \n  •  **Function : **Mengirim Gambar Peler.\
        \n\n  •  **Syntax :** `{cmd}ahh`\
        \n  •  **Function : **Mengirim Gambar Uhh Ahh Uhh Ahh.\
    "
    }
)
